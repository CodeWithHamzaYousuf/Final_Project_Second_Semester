<?php
session_start();
error_reporting(1);
include('connect.php');

date_default_timezone_set('Africa/Lagos');
$current_date = date('Y-m-d H:i:s');

if(isset($_POST["btnverify"]))
{
$ID = mysqli_real_escape_string($conn,$_POST['txtvaccinationID']);
$sql_verify = "select * from users where vaccinationID='$ID'"; 
$result_verify = $conn->query($sql_verify);
$row_verify = mysqli_fetch_array($result_verify);

$status="Status:"." ".$row_verify['status'];
$fullname="Fullname:"." ".$row_verify['fullname'];


  $query = "SELECT * FROM vaccination where vaccinationID='$ID'"; 
       $result = mysqli_query($conn, $query); 
      
    if ($result) 
    { 
        // it return number of rows in the table. 
        $row_vaccination = "No. of Visit(Vaccination):"." ".mysqli_num_rows($result); 
          
    }        


}


                 
     
    ?>

<!DOCTYPE html>
<html  >
<head>
    <!-- HEALTH SHIELD -->
     <!-- basic -->
     <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Covido</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
       <link rel="stylesheet" href="css/owl.carousel.min.css"> 
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">

  <!-- Site made with Mobirise Website Builder v5.3.10, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.10, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/akwa-ibom-logo.jfif" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Verification Panel|Covid-19 Directory for Vaccination</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/animatecss/animate.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/formstyler/jquery.formstyler.css">
  <link rel="stylesheet" href="assets/formstyler/jquery.formstyler.theme.css">
  <link rel="stylesheet" href="assets/datepicker/jquery.datetimepicker.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
</head>
<body>
  
<section class="menu cid-s48OLK6784" once="menu" id="menu1-h">
    
    <nav class="navbar navbar-dropdown navbar-expand-lg">
        <div class="container">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="index.php">
                        <img src="assets/images/logo.png" alt="covid-19 directory " style="height: 3.8rem;">                    </a>                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-7" href="index.php">HEALTH SHIELD</a></span>            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true"><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="index.php">Home</a></li>
				<li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="take action.php">Take Action</a></li>
                <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="register.php">Registration</a></li>
				<li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="verification.php">Verification Panel</a></li>
				<li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="./admin/login.php">Login</a></li>

			  </ul>
            </div>
        </div>
    </nav>

</section>

 <!-- cases -->
 <div class="cases">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage text_align_center ">
                     <h2>Protect Yourself</h2>
                     <p>Protect Yourself from these diseases with vaccination</p>
                  </div>
               </div>
            </div>
            <div class="row d_flex">
               <div class=" col-md-4">
                  <div class="latest text_align_center">
                     <figure><img src="images/cases1.png" alt="#"/></figure>
                     <div class="nostrud">
                        <h3>Malaria</h3>
                        <p>Malaria is a life-threatening disease caused by parasites transmitted through the bites of infected Anopheles mosquitoes. Symptoms often include fever, chills, headache, and fatigue, and can escalate to severe complications if untreated. Preventative measures are critical, especially in endemic regions, including the use of insecticide-treated nets, indoor spraying, and prophylactic medications. The RTS,S/AS01 vaccine offers additional protection for children in high-risk areas.</p>
                     </div>
                  </div>
               </div>
               <div class=" col-md-4">
                  <div class="latest text_align_center">
                     <figure><img src="images/cases2.png" alt="#"/></figure>
                     <div class="nostrud">
                        <h3>Polio</h3>
                        <p>Polio, or poliomyelitis, is a highly contagious viral infection that primarily affects children, potentially leading to paralysis or even death. The poliovirus spreads through contaminated food and water, and it can cause flu-like symptoms in some individuals, while others may remain asymptomatic. Vaccination is the most effective way to prevent polio, with the inactivated poliovirus vaccine (IPV) and the oral poliovirus vaccine (OPV) playing crucial roles in global eradication efforts.</p>
                     </div>
                  </div>
               </div>
               <div class=" col-md-4">
                  <div class="latest text_align_center">
                     <figure><img src="images/cases3.png" alt="#"/></figure>
                     <div class="nostrud">
                        <h3>Mumps</h3>
                        <p>mumps parag
                           Mumps is a contagious viral infection caused by the mumps virus, characterized by swelling of the salivary glands, particularly the parotids, leading to a puffy appearance of the cheeks and jaw. Other symptoms may include fever, headache, muscle aches, fatigue, and loss of appetite. Mumps spreads through respiratory droplets and direct contact with an infected person. Vaccination with the measles, mumps, and rubella (MMR) vaccine is the most effective way to prevent mumps</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end cases -->

 <!--  footer -->
 <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                        <div class="col-lg-2 col-md-6 col-sm-6">
                           <div class="hedingh3 text_align_left">
                              <h3>Resources</h3>
                              <ul class="menu_footer">
                                 <li><a href="index.html">Home</a><li>
                                 <li><a href="take action.php">Take Action</a><li>
                                 <li> <a href="register.php">Registration</a><li>
                                 <li> <a href="verification.php">Verfication Panel</a><li>
                                 <li> <a href="./admin/login.php">Login</a><li>

                              </ul>
                             
           
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                           <div class="hedingh3 text_align_left">
                             <h3>About</h3>
                              <p>Vaccination not only helps protect individuals from serious illnesses but also plays a crucial role in preventing the spread of diseases within communities, contributing to overall public health and safety.</p>
                           </div>
                        </div>
                     
                
                       
                        <div class="col-lg-3 col-md-6 col-sm-6">
                           <div class="hedingh3  text_align_left">
                              <h3>Contact  Us</h3>
                                <ul class="top_infomation">
                        <li><i class="fa fa-map-marker" aria-hidden="true"></i>
                           Making this the first true  
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                           Call : +92-337-8022639
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                           <a href="Javascript:void(0)">Email : yousufh687@gmail.com</a>
                        </li>
                     </ul>
                            
                           
                     </div>
                  </div>
                     <div class="col-lg-4 col-md-6 col-sm-6">
                           <div class="hedingh3 text_align_left">
                              <h3>countrys</h3>
                              <div class="map">
                                <img src="images/map.png" alt="#"/>
                              </div>
                           </div>
                        </div>
                    
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-8 offset-md-2">
                        <p>© 2024 All Rights Reserved. Design by <a href="https://html.design/"> Free html Templates</a></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/custom.js"></script>
</body>
</html>


<div class="hero">
    <div class="highway">

    </div>
</div>